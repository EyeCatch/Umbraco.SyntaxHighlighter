function init() {
    tinyMCEPopup.resizeToInnerSize();
	
	var codearea = document.getElementById('codearea');
	var ed = tinyMCEPopup.editor;
    var el = ed.selection.getNode();
	var action = "insert";
	
	el = ed.dom.getParent(el, "PRE");
	
	// If node has content, do update instead
	if (el != null && el.nodeName == "PRE") {
        action = "update";
	}
		
	// Change button text accordingly
	var insertButton = document.getElementById('insert');
	insertButton.value = tinyMCEPopup.getLang(action, 'Insert', true);	
	
	// Set code area content
	codearea.innerHTML = el.innerHTML;
	
	// Set options
	if (action == "update") {	
		var options = ed.dom.getAttrib(el, 'class');
		
		var brush = GetOption(options, 'brush');
		var autolinks = GetOption(options, 'auto-links');
		var classname = GetOption(options, 'classname');
		var collapse = GetOption(options, 'collapse');
		var firstline = GetOption(options, 'first-line');
		var gutter = GetOption(options, 'gutter');
		var highlight = GetOption(options, 'highlight');
		var htmlscript = GetOption(options, 'html-script');
		var smarttabs = GetOption(options, 'smart-tabs');
		var tabsize = GetOption(options, 'tab-size');
		var toolbar = GetOption(options, 'toolbar');
		
		if (brush) {
			document.getElementById('programminglanguages').value = brush;
		}
		
		if (autolinks && autolinks != "true") {
			document.getElementById("autolinks").checked = false;
		}

		if (classname && classname != "") {
			document.getElementById("classname").value = classname;
		}
			  
		if (collapse && collapse != "false") {
			document.getElementById("collapse").checked = true;
		}
			  
		if (firstline && firstline != "") {
			document.getElementById("firstline").value = firstline;
		}
		
		if (gutter && gutter == "false") {
			document.getElementById("gutter").checked = false;
		}
		
		if (highlight && highlight != "") {
			document.getElementById("highlight").value = highlight;
		}
		
		if (htmlscript && htmlscript == "true") {
			document.getElementById("htmlscript").checked = true;
		}
		
		if (smarttabs && smarttabs == "false") {
			document.getElementById("smarttabs").checked = false; 
		}
		
		if (tabsize && tabsize != "") {
			document.getElementById("tabsize").value = tabsize;
		}
		
		if (toolbar && toolbar == "false") {
			document.getElementById("toolbar").checked = false;
		}
	}
}

function GetOption(options, attrib) {
	var regexp = attrib + ": ";
	var position = options.search(regexp);
	
	// Contains option
	if (position > -1) {
		var start = position + regexp.length;
		var stop = options.indexOf(";", start);
		
		var option = options.substring(start, stop);
		
		return option;
	}
}

function Save_Button_onclick() {
	var lang = document.getElementById("programminglanguages").value;	
	var options = GetOptions();
	
	var code = "<pre class=\"brush: " + lang + "; " + ToOptionString(options) + "\">"; 
	code += EscapeHtml(document.getElementById("codearea").value);
	code += "</pre>";
	
	var scripts = "";
	
	if (document.getElementById("codearea").value == '')
	{
		tinyMCEPopup.close();
		return false;
	}
	
	// Set new content
	var ed = tinyMCEPopup.editor;
    var el = ed.selection.getNode();
	
	el = ed.dom.getParent(el, "PRE");
	
	tinyMCEPopup.execCommand("mceBeginUndoLevel");
	
	// Remove old node
	if (el != null && el.nodeName == "PRE") {
		i = ed.selection.getBookmark();
		el.innerHTML = "";
		ed.dom.remove(el, 1);
		ed.selection.moveToBookmark(i);
	}
	
	tinyMCEPopup.execCommand('mceInsertContent', false, code);
	
	tinyMCEPopup.execCommand("mceEndUndoLevel");
	
	tinyMCEPopup.close();
	return false;
}

function GetOptions() {
	var options = {
		autolinks: true,
		classname: '',
		collapse: false,
		firstline: 1,
		gutter: true,
		highlight: '',
		htmlscript: false,
		smarttabs: true,
		tabsize: 4,
		toolbar: true
	};
	
	if (document.getElementById("autolinks").checked == false) {
		options.autolinks = false;
	}

	if (document.getElementById("classname").value != "") {
		options.classname = document.getElementById("classname").value;
	}
		  
	if (document.getElementById("collapse").checked == true) {
		options.collapse = true;
	}
		  
	if (document.getElementById("firstline").value != "") {
		options.firstline = document.getElementById("firstline").value;
	}
	
	if (document.getElementById("gutter").checked == false) {
		options.gutter = false;
	}
	
	if (document.getElementById("highlight").value != "") {
		options.highlight = document.getElementById("highlight").value;
	}
	
	if (document.getElementById("htmlscript").checked == true) {
		options.htmlscript = true;
	}
	
	if (document.getElementById("smarttabs").checked == false) {
		options.smarttabs = false; 
	}
	
	if (document.getElementById("tabsize").value != "") {
		options.tabsize = document.getElementById("tabsize").value;
	}
	
	if (document.getElementById("toolbar").checked == false) {
		options.toolbar = false;
	}
   
	return options;
}

function ToOptionString(options) {
	var optionstring = "";
	
	if (options.autolinks == false) {
		optionstring += "auto-links: false; ";
	}

	if (options.classname != "") {
		optionstring += "class-name: " + options.classname + "; ";
	}
		  
	if (options.collapse == true) {
		optionstring += "collapse: true; ";
	}
		  
	if (options.firstline != 1) {
		optionstring += "first-line: " + options.firstline + "; ";
	}
	
	if (options.gutter == false) {
		optionstring += "gutter: false; ";
	}
	
	if (options.highlight != "") {
		optionstring += "highlight: " + options.highlight + "; ";
	}
	
	if (options.htmlscript == true) {
		optionstring += "html-script: true; ";
	}
	
	if (options.smarttabs == false) {
		optionstring += "smart-tabs: false; ";
	}
	
	if (options.tabsize != 4) {
		optionstring += "tab-size: " + options.tabsize + "; ";
	}
	
	if (options.toolbar == false) {
		optionstring += "toolbar: false; ";
	}
   
	return optionstring;
}

function Cancel_Button_onclick()
{
	tinyMCEPopup.close();
	return false;
}

function EscapeHtml(html) {
	return html.replace(/&/gm,'&amp;').replace(/</gm,'&lt;').replace(/>/gm,'&gt;').replace(/"/gm,'&quot;');
}

// On load
tinyMCEPopup.onInit.add(init);