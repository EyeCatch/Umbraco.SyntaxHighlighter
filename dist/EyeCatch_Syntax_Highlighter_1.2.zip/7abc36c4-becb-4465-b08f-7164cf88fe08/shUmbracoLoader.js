var UmbracoSyntaxHighlighter = UmbracoSyntaxHighlighter || {};

UmbracoSyntaxHighlighter.ContentLoaded = function(win, fn) {
    var done = false, top = true,
        doc = win.document, root = doc.documentElement,
        add = doc.addEventListener ? 'addEventListener' : 'attachEvent',
        rem = doc.addEventListener ? 'removeEventListener' : 'detachEvent',
        pre = doc.addEventListener ? '' : 'on',
        init = function(e) {
            if (e.type == 'readystatechange' && doc.readyState != 'complete') return;
            (e.type == 'load' ? win : doc)[rem](pre + e.type, init, false);
            if (!done && (done = true)) fn.call(win, e.type || e);
        },
        poll = function() {
            try {
                root.doScroll('left');
            } catch(e) {
                setTimeout(poll, 50);
                return;
            }
            init('poll');
        };

    if (doc.readyState == 'complete') fn.call(win, 'lazy');
    else {
        if (doc.createEventObject && root.doScroll) {
            try {
                top = !win.frameElement;
            } catch(e) {
            }
            if (top) poll();
        }
        doc[add](pre + 'DOMContentLoaded', init, false);
        doc[add](pre + 'readystatechange', init, false);
        win[add](pre + 'load', init, false);
    }
};

UmbracoSyntaxHighlighter.ContentLoaded(window, function () {
	SyntaxHighlighter.autoloader(
		'applescript            /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushAppleScript.js',
		'actionscript3 as3      /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushAS3.js',
		'bash shell             /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushBash.js',
		'coldfusion cf          /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushColdFusion.js',
		'cpp c                  /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushCpp.js',
		'c# c-sharp csharp      /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushCSharp.js',
		'css                    /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushCss.js',
		'delphi pascal          /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushDelphi.js',
		'diff patch pas         /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushDiff.js',
		'erl erlang             /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushErlang.js',
		'groovy                 /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushGroovy.js',
		'java                   /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushJava.js',
		'jfx javafx             /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushJavaFX.js',
		'js jscript javascript  /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushJScript.js',
		'perl pl                /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushPerl.js',
		'php                    /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushPhp.js',
		'text plain             /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushPlain.js',
		'py python              /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushPython.js',
		'ruby rails ror rb      /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushRuby.js',
		'sass scss              /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushSass.js',
		'scala                  /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushScala.js',
		'sql                    /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushSql.js',
		'vb vbnet               /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushVb.js',
		'xml xhtml xslt html    /umbraco_client/tinymce3/plugins/syntaxhighlighter/scripts/brushes/shBrushXml.js'
	);

	SyntaxHighlighter.all();
});